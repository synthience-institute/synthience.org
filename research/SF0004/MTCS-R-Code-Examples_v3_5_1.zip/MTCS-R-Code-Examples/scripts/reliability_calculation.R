# Inter-Rater Reliability Calculation for MTCS-R
# SF0004 Companion Material
# Author: Thomas W. Gantz | Synthience Institute
# Version: 3.5.1 (May 2026)
#
# Code Examples archive v3.5.1 ships with SF0004 (current version: synthience.org).
# v3.5.1 changes: archive-level cleanup only; no functional changes to this script.
# Archive requirements.txt was trimmed to honest runtime imports and the
# README BibTeX block was replaced with the version-independent form.
#
# v3.5 changes: paper-version coupling removed. References to the SF0004 paper
# are now version-independent. No functional changes.
#
# v3.4 changes (carried forward): archive-level cross-document alignment cycle.
# Paper references bumped from v3.2 to v3.3 across all archive files;
# companion-document filenames in the README updated to v3.3. No functional
# changes to the public reliability functions.
#
# v3.3 changes (carried forward): header bumped to align with archive version
# (companion to the semantic_drift.py inversion fix in v3.3). No functional
# changes to the public reliability functions in v3.3.
#
# v3.2 changes (carried forward): example_analysis() now uses the exact sample
# data shipped in data/sample_scores.csv (3 conversations x 3 raters) so the
# inline example matches the file. README first-run model download note added.
#
# This script computes the target reliability measures specified in SF0004
# Section 9.1: ICC(2,k) and Krippendorff's alpha. Target reliability follows the
# conventional thresholds proposed by Cicchetti (1994) for behavioral and
# clinical rating instruments: ICC > 0.60 (good agreement) or > 0.75 (excellent
# agreement). The 0.60 floor is the minimum threshold below which anchor
# revision is mandatory rather than an acceptance target.
#
# Cicchetti, D. V. (1994). Psychological Assessment, 6(4), 284-290.
# Shrout, P. E. & Fleiss, J. L. (1979). Psychological Bulletin, 86(2), 420-428.

# Required packages
if (!require("irr")) install.packages("irr")
if (!require("psych")) install.packages("psych")

library(irr)
library(psych)

# Function: Calculate Cohen's Kappa for 2 raters
calculate_cohens_kappa <- function(rater1, rater2, weights = "linear") {
  # Calculate Cohen's kappa for ordinal data.
  #
  # Parameters:
  #   rater1, rater2: numeric vectors of ratings
  #   weights: 'linear' for weighted kappa (recommended for ordinal)
  #
  # Returns:
  #   kappa object with value and p-value
  ratings <- data.frame(rater1 = rater1, rater2 = rater2)
  result <- kappa2(ratings, weight = weights)
  return(result)
}

# Function: Calculate Krippendorff's Alpha for multiple raters
calculate_krippendorffs_alpha <- function(ratings_matrix, method = "ordinal") {
  # Calculate Krippendorff's alpha for multiple raters.
  #
  # Parameters:
  #   ratings_matrix: matrix where rows = raters, columns = items
  #   method: 'ordinal' for MTCS-R scores
  #
  # Returns:
  #   alpha value
  result <- kripp.alpha(ratings_matrix, method = method)
  return(result)
}

# Function: Calculate ICC for continuous composite scores
# Note: SF0004 specifies ICC(2,k) for designs where raters are sampled
# from a larger population (model = "twoway", type = "agreement", unit = "average").
calculate_icc <- function(ratings_df, model = "twoway", type = "agreement",
                          unit = "average") {
  # Calculate Intraclass Correlation Coefficient.
  #
  # Parameters:
  #   ratings_df: data frame with columns for each rater
  #   model: 'oneway', 'twoway' (default 'twoway' for ICC(2,*))
  #   type: 'consistency' or 'agreement' (default 'agreement' for ICC(*,*))
  #   unit: 'single' for ICC(*,1) or 'average' for ICC(*,k); 'average' for
  #         the target SF0004 specifies
  #
  # Returns:
  #   ICC object with value and confidence interval
  result <- ICC(ratings_df, model = model, type = type, unit = unit)
  return(result)
}

# Helper: Interpret reliability per Cicchetti (1994) thresholds
interpret_reliability <- function(value) {
  if (is.na(value)) return("undefined")
  if (value < 0.40) return("Poor (below acceptable; revise anchors)")
  if (value < 0.60) return("Fair (below acceptable; revise anchors)")
  if (value < 0.75) return("Good (acceptable; further calibration recommended)")
  return("Excellent")
}

# Example usage with the sample data shipped in this archive.
# This function reproduces a complete reliability analysis using the values
# in data/sample_scores.csv, so the inline example matches the file.
example_analysis <- function() {
  # Sample data: 3 conversations x 3 raters, exactly as shipped in
  # data/sample_scores.csv. Scores are arranged conv_001, conv_002, conv_003.

  # D2 scores (ordinal, 1-5) - rater_B disagrees with A and C on conv_001
  rater_A_D2 <- c(5, 3, 2)
  rater_B_D2 <- c(4, 3, 2)
  rater_C_D2 <- c(5, 3, 2)

  # D4 scores (ordinal, 1-5) - rater_C disagrees with A and B on all three
  rater_A_D4 <- c(4, 3, 1)
  rater_B_D4 <- c(4, 3, 1)
  rater_C_D4 <- c(3, 2, 2)

  # Composite scores (continuous, mean of D1-D5)
  rater_A_composite <- c(4.4, 3.6, 1.8)
  rater_B_composite <- c(4.2, 3.6, 2.0)
  rater_C_composite <- c(4.2, 3.4, 2.0)

  # ============================================================
  # Weighted Cohen's kappa - dimension-level, 2 raters
  # ============================================================
  # D2 example: rater_A vs rater_B (one disagreement on conv_001)
  kappa_D2 <- calculate_cohens_kappa(rater_A_D2, rater_B_D2)
  cat("Cohen's Kappa (weighted) for D2, rater_A vs rater_B:\n")
  print(kappa_D2)
  cat("Interpretation:", interpret_reliability(kappa_D2$value), "\n\n")

  # D4 example: rater_A vs rater_C (three disagreements - lower kappa)
  kappa_D4 <- calculate_cohens_kappa(rater_A_D4, rater_C_D4)
  cat("Cohen's Kappa (weighted) for D4, rater_A vs rater_C:\n")
  print(kappa_D4)
  cat("Interpretation:", interpret_reliability(kappa_D4$value), "\n\n")

  # ============================================================
  # Krippendorff's alpha - dimension-level, 3 raters
  # ============================================================
  # Rows = raters, columns = conversations
  ratings_D4 <- matrix(c(
    rater_A_D4,
    rater_B_D4,
    rater_C_D4
  ), nrow = 3, byrow = TRUE)

  alpha_D4 <- calculate_krippendorffs_alpha(ratings_D4)
  cat("Krippendorff's Alpha for D4 across 3 raters:\n")
  print(alpha_D4)
  cat("Interpretation:", interpret_reliability(alpha_D4$value), "\n\n")

  # ============================================================
  # ICC(2,k) - composite (descriptive index), 3 raters
  # ============================================================
  # Per SF0004 Section 5.1, the composite is a descriptive index only;
  # always also report dimension-level reliability (above).
  composite_scores <- data.frame(
    rater_A = rater_A_composite,
    rater_B = rater_B_composite,
    rater_C = rater_C_composite
  )

  icc_result <- calculate_icc(composite_scores)
  cat("Intraclass Correlation Coefficient (ICC(2,k), agreement) for composite:\n")
  print(icc_result)
  cat("Note: report dimension-level reliability separately, not just the composite.\n")
  cat("The composite is a descriptive index per SF0004 Section 5.1;\n")
  cat("the dimensional profile is the primary result.\n\n")

  # Note on sample size: 3 conversations is a demonstration scale only.
  # Phase 1 reliability studies should use the larger corpora described in
  # SF0004 Section 9.1 and the Rater Training Packet Section 5.
  cat("Note: this example uses 3 conversations only. Phase 1 reliability\n")
  cat("studies should use the larger corpora described in SF0004\n")
  cat("Section 9.1 and the Rater Training Packet Section 5.\n")
}

# Run example
if (interactive()) {
  example_analysis()
}

# Helper function: Load scores from CSV and compute pairwise kappa
# Compatible with the sample_scores.csv format in this archive
# (columns: conversation_id, rater_id, D1_score..D5_score, composite)
load_scores_and_analyze <- function(filepath, dimension = "composite",
                                     rater1_id = "rater_A",
                                     rater2_id = "rater_B") {
  # Load MTCS-R scores from CSV and calculate reliability for one dimension.
  #
  # Parameters:
  #   filepath: path to CSV file in the sample_scores.csv format
  #   dimension: column name to analyze (e.g., 'D1_score', 'composite')
  #   rater1_id, rater2_id: rater_id values to compare
  data <- read.csv(filepath)

  # Subset and reshape to two parallel vectors of scores per rater
  r1 <- data[data$rater_id == rater1_id, c("conversation_id", dimension)]
  r2 <- data[data$rater_id == rater2_id, c("conversation_id", dimension)]
  merged <- merge(r1, r2, by = "conversation_id", suffixes = c("_1", "_2"))

  rater1_scores <- merged[[paste0(dimension, "_1")]]
  rater2_scores <- merged[[paste0(dimension, "_2")]]

  if (dimension == "composite") {
    # Use ICC for continuous composite
    df <- data.frame(rater1 = rater1_scores, rater2 = rater2_scores)
    result <- calculate_icc(df, unit = "average")
    cat("ICC(2,k) for composite (descriptive index):\n")
    print(result)
    return(result)
  } else {
    # Use weighted kappa for ordinal dimension scores
    result <- calculate_cohens_kappa(rater1_scores, rater2_scores)
    cat("Weighted kappa for", dimension, ":\n")
    print(result)
    cat("Interpretation:", interpret_reliability(result$value), "\n")
    return(result)
  }
}

# Example usage with the sample data shipped in this archive:
# load_scores_and_analyze("data/sample_scores.csv", dimension = "D1_score",
#                         rater1_id = "rater_A", rater2_id = "rater_B")
# load_scores_and_analyze("data/sample_scores.csv", dimension = "composite")
