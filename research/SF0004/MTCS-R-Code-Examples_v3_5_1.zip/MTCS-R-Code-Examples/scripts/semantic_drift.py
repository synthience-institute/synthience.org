"""
Semantic Drift Analysis for MTCS-R
Analyzes semantic similarity changes across conversation turns using embeddings.

SF0004 Companion Material
Author: Thomas W. Gantz | Synthience Institute
Version: 3.5.1 (May 2026)

v3.5.1: archive-level cleanup only; no functional changes to this script.
Archive requirements.txt was trimmed to honest runtime imports and the
README BibTeX block was replaced with the version-independent form.

v3.5: paper-version coupling removed. References to the SF0004 paper are now
version-independent. No functional changes.

v3.4: no code changes from v3.3; archive-level cross-document alignment cycle
that bumped paper references to SF0004 across all archive files.

v3.3 fix: corrected drift computation in 'consecutive' and 'cumulative' modes.
Previous versions computed cosine SIMILARITY (1 - distance) but labeled it as
drift, causing high-similarity adjacent turns to register as high "drift".
v3.3 uses scipy.spatial.distance.cosine() directly, which returns cosine
distance (the correct drift metric: 0 for identical, larger for more drift).
The 'windowed' mode was already correct in prior versions.

This is a methodological demonstration, not a validated MTCS-R metric. Semantic
drift is one possible computational signal that may correlate with thematic
trajectory degradation (D1) or contextual integration patterns (D2), but the
relationship between embedding-based drift and human MTCS-R ratings has not
been empirically established. Pilot test against human scores before drawing
conclusions; see SF0004 Section 10.
"""

from sentence_transformers import SentenceTransformer
from scipy.spatial.distance import cosine
import numpy as np
from typing import List, Dict

def analyze_drift(turns: List[str],
                 model_name: str = 'all-MiniLM-L6-v2',
                 drift_type: str = 'consecutive') -> Dict:
    """
    Analyze semantic drift across conversation turns.

    Parameters:
    -----------
    turns : List[str]
        List of conversation turns in order
    model_name : str
        SentenceTransformer model name
        Options: 'all-MiniLM-L6-v2' (fast), 'all-mpnet-base-v2' (quality)
    drift_type : str
        'consecutive': Compare adjacent turns
        'cumulative': Compare each turn to initial turn
        'windowed': Compare within sliding window

    Returns:
    --------
    dict with drift metrics and embeddings
    """
    # Load embedding model
    model = SentenceTransformer(model_name)

    # Encode all turns
    embeddings = model.encode(turns, show_progress_bar=False)

    results = {
        'model': model_name,
        'num_turns': len(turns),
        'embeddings': embeddings
    }

    if drift_type == 'consecutive':
        # Drift between consecutive turns = cosine distance between adjacent embeddings.
        # scipy.spatial.distance.cosine(a, b) returns cosine distance (1 - cosine_similarity),
        # which is the correct drift metric. Range: 0 (identical) to 2 (opposite).
        # In practice, sentence-transformer embeddings yield values in roughly [0, 1].
        drift_scores = [
            cosine(embeddings[i], embeddings[i+1])
            for i in range(len(embeddings)-1)
        ]
        results['drift_scores'] = drift_scores
        results['mean_drift'] = np.mean(drift_scores)
        results['std_drift'] = np.std(drift_scores)

    elif drift_type == 'cumulative':
        # Drift from the first turn = cosine distance from embedding 0 to embedding i.
        drift_scores = [
            cosine(embeddings[0], embeddings[i])
            for i in range(1, len(embeddings))
        ]
        results['cumulative_drift'] = drift_scores
        results['mean_drift'] = np.mean(drift_scores)

    elif drift_type == 'windowed':
        # Windowed analysis (window size = 5)
        window_size = min(5, len(embeddings))
        drift_scores = []
        for i in range(len(embeddings) - window_size + 1):
            window = embeddings[i:i+window_size]
            # Average pairwise similarity within window
            sims = []
            for j in range(len(window)):
                for k in range(j+1, len(window)):
                    sims.append(1 - cosine(window[j], window[k]))
            drift_scores.append(1 - np.mean(sims))  # Invert for drift
        results['windowed_drift'] = drift_scores
        results['mean_drift'] = np.mean(drift_scores)

    return results


def detect_drift_points(drift_scores: List[float],
                       threshold: float = 0.3) -> List[int]:
    """
    Identify turns where drift exceeds threshold.

    Parameters:
    -----------
    drift_scores : List[float]
        Drift scores from analyze_drift() (cosine distance values, 0=identical, higher=more drift)
    threshold : float
        Drift threshold; values above this are flagged as high drift
        For sentence-transformer embeddings on adjacent conversational turns,
        typical values fall in roughly [0.1, 0.6]; 0.3 is a moderate default.

    Returns:
    --------
    List of turn indices with high drift
    """
    return [i+1 for i, score in enumerate(drift_scores) if score > threshold]


def plot_drift_trajectory(drift_scores: List[float],
                         title: str = 'Semantic Drift Trajectory',
                         save_path: str = None):
    """
    Visualize drift across turns.

    Parameters:
    -----------
    drift_scores : List[float]
        Drift scores from analyze_drift()
    title : str
        Plot title
    save_path : str
        Optional path to save figure
    """
    import matplotlib.pyplot as plt

    plt.figure(figsize=(10, 5))
    plt.plot(range(1, len(drift_scores)+1), drift_scores,
             marker='o', linestyle='-', linewidth=2, markersize=4)
    plt.xlabel('Turn Transition', fontsize=12)
    plt.ylabel('Drift Score (cosine distance)', fontsize=12)
    plt.title(title, fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()


# Example usage
if __name__ == "__main__":
    # Sample conversation
    sample_turns = [
        "I need help with my Python code.",
        "Sure, what's the issue you're encountering?",
        "I'm getting a syntax error on line 15.",
        "Can you share the error message?",
        "It says 'invalid syntax' near the for loop.",
        "Let's check your loop syntax. Did you include a colon?",
        "Oh yes, I forgot the colon!",
        "Great! That should fix it."
    ]

    # Analyze drift
    results = analyze_drift(sample_turns, drift_type='consecutive')
    print(f"Mean drift: {results['mean_drift']:.3f}")
    print(f"Std drift: {results['std_drift']:.3f}")

    # Detect high drift points
    high_drift = detect_drift_points(results['drift_scores'], threshold=0.2)
    print(f"High drift at transitions: {high_drift}")

    # Plot trajectory
    plot_drift_trajectory(results['drift_scores'])
