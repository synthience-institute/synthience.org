"""
Perplexity Trajectory Analysis for MTCS-R
Calculates per-turn perplexity to assess predictability changes.

SF0004 Companion Material
Author: Thomas W. Gantz | Synthience Institute
Version: 3.5.1 (May 2026)

Code Examples archive v3.5.1 ships with SF0004 (current version: synthience.org).
v3.5.1: archive-level cleanup only; no functional changes to this script.
Archive requirements.txt was trimmed to honest runtime imports and the
README BibTeX block was replaced with the version-independent form.

v3.5: archive bumped for paper-version coupling removal across all archive
files. No functional changes to this script.
The companion semantic_drift.py was substantively fixed in v3.3 (see
its header for details).

This is a methodological demonstration. Per-turn perplexity is one possible
computational signal that may correlate with coherence trajectory features,
but the relationship between perplexity and human MTCS-R ratings has not been
empirically established. Perplexity is sensitive to topic, style, and rare
vocabulary; it does not directly measure any of the five MTCS-R dimensions.
Pilot test against human scores before drawing conclusions; see SF0004
Section 10.
"""

from transformers import GPT2LMHeadModel, GPT2TokenizerFast
import torch
import numpy as np
from typing import List, Dict

def calculate_perplexity_trajectory(turns: List[str],
                                   model_name: str = 'gpt2',
                                   cumulative: bool = False) -> List[float]:
    """
    Calculate perplexity for each turn in conversation.

    Parameters:
    -----------
    turns : List[str]
        List of conversation turns
    model_name : str
        HuggingFace model name (e.g., 'gpt2', 'gpt2-medium')
    cumulative : bool
        If True, calculate perplexity on cumulative context
        If False, calculate per-turn perplexity

    Returns:
    --------
    List of perplexity values (one per turn)

    Notes:
    ------
    - Lower perplexity = more predictable
    - Context window: 1024 tokens for gpt2
    - See SF0004 Section 10 for limitations of computational proxies
      relative to human MTCS-R ratings
    """
    model = GPT2LMHeadModel.from_pretrained(model_name)
    tokenizer = GPT2TokenizerFast.from_pretrained(model_name)
    model.eval()

    perplexities = []

    if cumulative:
        # Calculate perplexity on growing context
        context = ""
        for turn in turns:
            context += turn + " "
            perp = _calculate_single_perplexity(context, model, tokenizer)
            perplexities.append(perp)
    else:
        # Calculate perplexity per individual turn
        for turn in turns:
            perp = _calculate_single_perplexity(turn, model, tokenizer)
            perplexities.append(perp)

    return perplexities


def _calculate_single_perplexity(text: str,
                                 model,
                                 tokenizer) -> float:
    """
    Calculate perplexity for single text segment.
    """
    encodings = tokenizer(text, return_tensors='pt')

    # Handle sequences longer than max length
    max_length = model.config.n_positions
    input_ids = encodings.input_ids

    if input_ids.size(1) > max_length:
        input_ids = input_ids[:, :max_length]

    with torch.no_grad():
        outputs = model(input_ids, labels=input_ids)
        loss = outputs.loss

    perplexity = torch.exp(loss).item()
    return perplexity


def analyze_perplexity_trends(perplexities: List[float]) -> Dict:
    """
    Analyze trends in perplexity trajectory.

    Parameters:
    -----------
    perplexities : List[float]
        Perplexity values from calculate_perplexity_trajectory()

    Returns:
    --------
    dict with trend statistics
    """
    perp_arr = np.array(perplexities)

    # Calculate trend
    turns = np.arange(len(perplexities))
    slope, intercept = np.polyfit(turns, perp_arr, 1)

    results = {
        'mean_perplexity': float(np.mean(perp_arr)),
        'std_perplexity': float(np.std(perp_arr)),
        'min_perplexity': float(np.min(perp_arr)),
        'max_perplexity': float(np.max(perp_arr)),
        'trend_slope': float(slope),
        'increasing': slope > 0
    }

    return results


def plot_perplexity_trajectory(perplexities: List[float],
                               title: str = 'Perplexity Trajectory',
                               save_path: str = None):
    """
    Visualize perplexity across turns.

    Parameters:
    -----------
    perplexities : List[float]
        Perplexity values
    title : str
        Plot title
    save_path : str
        Optional save path
    """
    import matplotlib.pyplot as plt

    plt.figure(figsize=(10, 5))
    plt.plot(range(1, len(perplexities)+1), perplexities,
             marker='o', linestyle='-', linewidth=2, markersize=4,
             color='#4472C4')
    plt.xlabel('Turn Number', fontsize=12)
    plt.ylabel('Perplexity', fontsize=12)
    plt.title(title, fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()


# Example usage
if __name__ == "__main__":
    # Sample conversation
    sample_turns = [
        "I need help with my Python code.",
        "Sure, what's the issue you're encountering?",
        "I'm getting a syntax error on line 15.",
        "Can you share the error message?",
        "It says 'invalid syntax' near the for loop.",
        "Let's check your loop syntax. Did you include a colon?",
        "Oh yes, I forgot the colon!",
        "Great! That should fix it."
    ]

    print("Calculating perplexities...")
    perplexities = calculate_perplexity_trajectory(sample_turns)

    print(f"\nPerplexity values:")
    for i, perp in enumerate(perplexities, 1):
        print(f"Turn {i}: {perp:.2f}")

    # Analyze trends
    trends = analyze_perplexity_trends(perplexities)
    print(f"\nMean perplexity: {trends['mean_perplexity']:.2f}")
    print(f"Trend slope: {trends['trend_slope']:.2f}")
    print(f"Increasing: {trends['increasing']}")

    # Plot
    plot_perplexity_trajectory(perplexities)
