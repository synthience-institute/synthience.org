# MTCS-R Code Examples

Computational analysis tools for the Multi-Turn Coherence Scale, Revised (MTCS-R)

**Version:** 3.5.1
**SF0004 Companion Material**
**Author:** Thomas W. Gantz | Synthience Institute
**Contact:** research@synthience.org
**Date:** May 2026

## Overview

This archive provides example code for computational analysis of multi-turn human-AI conversations using MTCS-R. These are methodological demonstrations, not production-ready tools and not validated MTCS-R metrics. The relationships between embedding-based drift, language-model perplexity, and human MTCS-R ratings have not been empirically established. See SF0004 Section 10 for known limitations of computational proxies.

**v3.5.1 release note.** v3.5.1 cleans up `requirements.txt` to honestly reflect runtime imports: `krippendorff`, `scikit-learn`, and `seaborn` were removed (none imported by any shipped script or notebook). An explanatory comment was added at the top of `requirements.txt` noting that ICC and Krippendorff's alpha are computed by the R script `reliability_calculation.R`, not by Python. The README BibTeX block was replaced with the version-independent form used in LICENSE.txt and README\_FIRST.md, removing the prior contradiction with the v3.5 paper-version-coupling-removal claim. No code changes; archive structure unchanged.

**v3.5 release note.** v3.5 removes paper-version coupling from all archive files. References to the SF0004 paper are now version-independent: scripts and documentation reference "SF0004" by document ID without embedding a specific paper version. This decouples the archive from paper revisions so that future paper updates do not require coordinated archive bumps. The canonical record for current paper version and DOI is at synthience.org. No functional changes to any script.

**v3.4 release note (carried forward).** v3.4 fixed a documentation bug in the v3.3 README: the Contents section described `semantic_drift.py` as computing cosine similarity, which contradicted the v3.3 inversion fix in the script itself. v3.4 corrected the README description to match the actual (correct) v3.3 implementation. No code changes; the v3.3 inversion fix was preserved as-is. Companion-document filenames in the Related Documentation section were updated to the v3.3 versions of the Rater Training Packet and Scoring Template.

**v3.3 release note (carried forward).** The v3.3 release fixed a semantic-inversion bug in `semantic_drift.py` that was present in all prior versions of this script. The `consecutive` and `cumulative` drift modes were computing cosine *similarity* (high for similar adjacent turns) but labeling the result as drift, causing high-similarity adjacent turns to register as high "drift". v3.3 computes cosine *distance* directly, which is the correct drift metric (0 for identical, larger for more drift). The `windowed` mode was already correct in prior versions. If you used `semantic_drift.py` from a release prior to v3.3, the qualitative conclusions about which turn transitions had high vs. low values are inverted relative to drift; rerun with v3.3 or later to get correct results.

## Archive Structure

```
MTCS-R-Code-Examples/
├── README.md
├── requirements.txt
├── notebooks/
│   └── semantic_drift.ipynb
├── scripts/
│   ├── semantic_drift.py
│   ├── perplexity_analysis.py
│   └── reliability_calculation.R
└── data/
    ├── sample_transcripts.csv
    └── sample_scores.csv
```

## Quick Start

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

For the R script, install R (https://www.r-project.org/) and the `irr` and `psych` packages; the script will install them if not already available.

**First-run downloads.** On first invocation, `semantic_drift.py` downloads its sentence-transformer model (~80MB for `all-MiniLM-L6-v2`, ~420MB for `all-mpnet-base-v2`); `perplexity_analysis.py` downloads GPT-2 (~500MB) by default, or larger variants if you change `model_name`. Both cache locally after the first download. If you are working offline or have constrained bandwidth, plan accordingly.

## Contents

### Scripts

**semantic_drift.py** provides functions for calculating turn-to-turn and cumulative semantic drift using sentence embeddings. It computes cosine distance between adjacent turns and tracks cumulative drift across the full conversation trajectory. Methodological demonstration; not a validated D1 or D2 metric.

**perplexity_analysis.py** calculates per-turn perplexity using a language model, producing a perplexity trajectory that can indicate where in a conversation the AI system's output becomes less predictable. Perplexity is sensitive to topic, style, and rare vocabulary; it does not directly measure any of the five MTCS-R dimensions.

**reliability_calculation.R** computes inter-rater reliability statistics for MTCS-R scores, including ICC(2,k) and Krippendorff's alpha. This is the recommended tool for the target reliability measures specified in SF0004 Section 9.1. The MTCS-R Scoring Template (Excel) provides simple agreement percentage only; use this R script for the full reliability analysis. Reliability targets follow Cicchetti (1994) thresholds: ICC > 0.60 (good agreement) or > 0.75 (excellent agreement); the 0.60 floor is a minimum threshold below which anchor revision is mandatory rather than an acceptance target.

### Notebook

**semantic_drift.ipynb** provides a step-by-step walkthrough of embedding-based drift analysis with visualizations.

### Sample Data

**sample_transcripts.csv** contains short example conversations (6 turns each, synthetic) with columns: conversation_id, turn_number, speaker, turn_text. **These transcripts are below the MTCS-R design threshold of 20 participant turns and are not MTCS-R-scorable.** They are provided as minimal computational-proxy demonstration data only, sufficient for verifying that the embedding and perplexity scripts run end-to-end. For Phase 1 reliability studies, use full-length transcripts assembled per the Rater Training Packet Section 5 guidance.

**sample_scores.csv** contains example MTCS-R ratings with columns: conversation_id, rater_id, D1_score through D5_score, D5_domain_competence (a brief note recording the domain-competence basis on which each D5 score was assigned, per SF0004 Section 11), and composite (the descriptive-index average of D1-D5). The scores are illustrative values demonstrating the data layout; they are not derived from the short sample_transcripts.csv (which is below the scoring threshold) and should not be used to draw conclusions about rater agreement on those specific transcripts.

## Methodological Notes

### On computational proxies

Choice of embedding model affects drift sensitivity; semantic similarity is not identical to thematic coherence. Perplexity may not correlate with human judgments. Reliability metrics assume independence; adjust for nested or hierarchical data structures. Pilot test any computational metric against human MTCS-R scores before drawing conclusions.

### On the composite score

The composite (mean of D1-D5) is a descriptive index for compact reporting only, per SF0004 Section 5.1. The five-score dimensional profile is the primary MTCS-R result. Always report all five dimension scores; never report the composite alone. The composite is not a validated latent score.

### On D5 domain competence

D5 (Epistemic Calibration) requires raters to evaluate the epistemic status of substantive claims in the interaction (established, uncertain, speculative, unverifiable, or false). For interactions in specialized domains, raters should have appropriate domain competence, or D5 scoring should be flagged as provisional. The sample_scores.csv records the domain-competence basis on which each D5 score was assigned; studies using MTCS-R should follow the same convention per SF0004 Section 11.

### Pre-Phase 2 status

MTCS-R has not yet been empirically validated. The behavioral anchors and the proposed five-factor structure are theoretically motivated and practitioner-refined, not empirically confirmed. Studies conducted prior to Phase 2 validation (SF0004 Section 9) should report scores accordingly, and should treat pre-Phase 2 results as exploratory evidence about both the proposed structure and the interactions being scored.

## Citation

```bibtex
@misc{gantz_mtcsr,
  author    = {Gantz, Thomas W.},
  title     = {Measurement Instruments and Validation Protocols:
               Multi-Turn Coherence Scale, Revised (MTCS-R)},
  publisher = {Synthience Institute},
  note      = {SF0004. Current version and DOI:
               synthience.org}
}
```

## Related Documentation

SF0004 is the primary methodological document.

The MTCS-R Scoring Template (`MTCS-R_Scoring_Template.xlsx`) provides Excel-based scoring forms.

The MTCS-R Rater Training Packet (`MTCS-R_Rater_Training_Packet.docx`) provides rater training materials.

Published Synthience Institute documents with DOIs:
- SR0001 RICO (10.5281/zenodo.18086834)
- SF0037 CVP (10.5281/zenodo.18075624)
- SF0039 CRD (10.5281/zenodo.18289391)

Methodological references:
- Cicchetti, D. V. (1994). Guidelines, Criteria, and Rules of Thumb for Evaluating Normed and Standardized Assessment Instruments in Psychology. Psychological Assessment, 6(4), 284-290. https://doi.org/10.1037/1040-3590.6.4.284
- Shrout, P. E. & Fleiss, J. L. (1979). Intraclass correlations: Uses in assessing rater reliability. Psychological Bulletin, 86(2), 420-428. https://doi.org/10.1037/0033-2909.86.2.420

## Contact

research@synthience.org | https://synthience.org

## License

CC-BY 4.0
